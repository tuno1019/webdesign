// JavaScript Document

$(document).ready(function(){
	
//click event
	$(".list").click(function(){
        $(this).addClass("ch_bg").siblings().removeClass("ch_bg");
		
	});


});